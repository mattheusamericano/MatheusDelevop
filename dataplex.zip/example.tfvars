# ============================================================
# Dataplex - Instâncias SIPML
# ============================================================
# O mesmo módulo é instanciado 3 vezes no SIPML:
#   1. spoke-modelagem  → governa BQ Sandbox + Feature Store (treino)
#   2. spoke-inferencia → governa Feature Store (serving) + logs operacionais
#   3. hub-features     → governa camada Curated compartilhada entre spokes
#
# Cada bloco abaixo é um terraform apply independente com workspace próprio.
# ============================================================

dataplex_settings = {

  # ----------------------------------------------------------
  # 1. SPOKE DE MODELAGEM
  #    Governa: BQ Sandbox (P&D), Feature Store analítica, logs de treino
  #    Projeto: prj-spoke-modelagem
  #    ADR-007: Dataplex como camada transversal de governança (MLOps)
  # ----------------------------------------------------------
  "modelagem" = {
    project_id       = "prj-spoke-modelagem"
    region           = "southamerica-east1"
    sigla            = "sipml"
    lake_description = "Governança do ciclo de vida analítico — sandbox, features e logs de treino"

    labels = {
      dominio     = "mlops-modelagem"
      cost_center = "ia-caixa"
      owner       = "sudea"
    }

    iam_groups = {
      admin  = "G_GCP_SIPML_ADMIN@corp.caixa.gov.br"
      viewer = "G_GCP_SIPML_MODELADORES@corp.caixa.gov.br"
      # editor não definido — time de modelagem não edita estrutura do lake, só consome
    }

    zones = {
      # Zona RAW: BQ Sandbox (dado bruto de P&D, ainda não tratado)
      "sandbox" = {
        zone_type          = "RAW"
        discovery_enabled  = true
        discovery_schedule = "0 5 * * *"
      }

      # Zona CURATED: Feature Store analítica (dado tratado, pronto para treino)
      "features-treino" = {
        zone_type          = "CURATED"
        discovery_enabled  = true
        discovery_schedule = "0 7 * * *"
      }
    }

    assets = {
      # BQ Sandbox — ambiente experimental dos cientistas de dados
      "bq-sandbox" = {
        zone_key          = "sandbox"
        resource_type     = "BIGQUERY_DATASET"
        resource_name     = "projects/prj-spoke-modelagem/datasets/ds_sandbox_pd"
        asset_description = "BigQuery Sandbox — experimentação e P&D de features (M1)"
        discovery_enabled = true
      }

      # Feature Store analítica — output do pipeline M2 (Vertex AI Pipelines)
      "bq-features-treino" = {
        zone_key          = "features-treino"
        resource_type     = "BIGQUERY_DATASET"
        resource_name     = "projects/prj-spoke-modelagem/datasets/ds_feature_store_treino"
        asset_description = "Repositório de features para treinamento — alimentado pelo Vertex AI Pipelines (M2)"
        discovery_enabled = true
      }
    }

    scans = {
      # Profile scan: entender distribuição das features antes do treino
      "features-treino-profile" = {
        scan_type               = "PROFILE"
        bq_table_resource       = "projects/prj-spoke-modelagem/datasets/ds_feature_store_treino/tables/features_consolidadas"
        scan_schedule           = "0 8 * * 1" # toda segunda
        sampling_percent        = 30
        export_results_dataset  = "projects/prj-spoke-modelagem/datasets/ds_dataplex_results/tables/profile_features_treino"
        exclude_fields          = ["cpf_hash", "conta_hash"]
      }

      # Quality scan: validar integridade das features antes de disparar treino
      "features-treino-quality" = {
        scan_type               = "QUALITY"
        bq_table_resource       = "projects/prj-spoke-modelagem/datasets/ds_feature_store_treino/tables/features_consolidadas"
        scan_schedule           = "0 6 * * *" # diário antes do treino
        sampling_percent        = 100
        incremental_field       = "dt_processamento"
        export_results_dataset  = "projects/prj-spoke-modelagem/datasets/ds_dataplex_results/tables/quality_features_treino"

        quality_rules = [
          {
            name      = "id_cliente_nao_nulo"
            column    = "id_cliente_hash"
            dimension = "COMPLETENESS"
            rule_type = "NON_NULL"
            threshold = 1.0
          },
          {
            name      = "score_risco_range"
            column    = "score_risco"
            dimension = "VALIDITY"
            rule_type = "RANGE"
            threshold = 1.0
            range = {
              min        = "0"
              max        = "1000"
              strict_min = false
              strict_max = false
            }
          },
          {
            name           = "segmento_valores_validos"
            column         = "segmento_cliente"
            dimension      = "VALIDITY"
            rule_type      = "SET"
            allowed_values = ["PF", "PJ", "MEI", "GOV"]
            threshold      = 1.0
          },
          {
            name          = "data_referencia_nao_futura"
            column        = "dt_referencia"
            dimension     = "ACCURACY"
            rule_type     = "SQL"
            sql_statement = "SELECT * FROM features_consolidadas WHERE dt_referencia > CURRENT_DATE()"
            threshold     = 1.0
          },
        ]
      }
    }
  }

  # ----------------------------------------------------------
  # 2. SPOKE DE INFERÊNCIA
  #    Governa: Feature Store serving (lookup online), logs operacionais, Model Monitoring
  #    Projeto: prj-spoke-inferencia
  #    Seção 5.4 / Camada 5 do documento: Dataplex atua externamente
  # ----------------------------------------------------------
  "inferencia" = {
    project_id       = "prj-spoke-inferencia"
    region           = "southamerica-east1"
    sigla            = "sipml"
    lake_description = "Governança do ciclo de vida operacional — features serving, logs de predição e model monitoring"

    labels = {
      dominio     = "mlops-inferencia"
      cost_center = "ia-caixa"
      owner       = "sudea"
    }

    iam_groups = {
      admin  = "G_GCP_SIPML_ADMIN@corp.caixa.gov.br"
      viewer = "G_GCP_SIPML_OPERACAO@corp.caixa.gov.br"
    }

    zones = {
      # Zona CURATED: Feature Store serving — lookup em tempo real pelo Vertex AI Endpoint
      "features-serving" = {
        zone_type          = "CURATED"
        discovery_enabled  = true
        discovery_schedule = "0 4 * * *"
      }

      # Zona RAW: Logs operacionais do Model Monitoring e predições
      "logs-operacionais" = {
        zone_type          = "RAW"
        discovery_enabled  = true
        discovery_schedule = "0 3 * * *"
      }
    }

    assets = {
      # Feature Store serving — consultada pelo Vertex AI Endpoint (I2/I3)
      "bq-features-serving" = {
        zone_key          = "features-serving"
        resource_type     = "BIGQUERY_DATASET"
        resource_name     = "projects/prj-spoke-inferencia/datasets/ds_feature_store_serving"
        asset_description = "Repositório de features para inferência online — lookup pelo Vertex AI Endpoint (I3)"
        discovery_enabled = true
      }

      # Logs operacionais — Model Monitoring + logs de predições (I4)
      "bq-logs-predicao" = {
        zone_key          = "logs-operacionais"
        resource_type     = "BIGQUERY_DATASET"
        resource_name     = "projects/prj-spoke-inferencia/datasets/ds_logs_operacionais"
        asset_description = "Logs operacionais de predições, métricas de drift e telemetria do Model Monitoring (I4)"
        discovery_enabled = true
      }
    }

    scans = {
      # Quality scan nas features serving — garantir que o dado de lookup é confiável
      "features-serving-quality" = {
        scan_type               = "QUALITY"
        bq_table_resource       = "projects/prj-spoke-inferencia/datasets/ds_feature_store_serving/tables/features_online"
        scan_schedule           = "0 2 * * *" # madrugada, antes do pico operacional
        sampling_percent        = 100
        incremental_field       = "dt_atualizacao"
        export_results_dataset  = "projects/prj-spoke-inferencia/datasets/ds_dataplex_results/tables/quality_features_serving"

        quality_rules = [
          {
            name      = "feature_chave_nao_nula"
            column    = "id_cliente_hash"
            dimension = "COMPLETENESS"
            rule_type = "NON_NULL"
            threshold = 1.0
          },
          {
            name          = "atualizacao_recente"
            column        = null
            dimension     = "ACCURACY"
            rule_type     = "SQL"
            # Alerta se alguma feature não foi atualizada nas últimas 25h (drift de pipeline)
            sql_statement = "SELECT * FROM features_online WHERE dt_atualizacao < TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 25 HOUR)"
            threshold     = 1.0
          },
        ]
      }

      # Profile scan nos logs: entender distribuição das predições (suporte ao Model Monitoring)
      "logs-predicao-profile" = {
        scan_type               = "PROFILE"
        bq_table_resource       = "projects/prj-spoke-inferencia/datasets/ds_logs_operacionais/tables/predicoes"
        scan_schedule           = "0 6 * * 1" # semanal
        sampling_percent        = 10           # logs são volumosos — amostragem menor
        export_results_dataset  = "projects/prj-spoke-inferencia/datasets/ds_dataplex_results/tables/profile_logs_predicao"
      }
    }
  }

  # ----------------------------------------------------------
  # 3. HUB DE FEATURES (Camada 4 — Orquestração e Governança)
  #    Governa: Camada Curated corporativa — Single Source of Truth
  #    Dados RAW → Curated (Dataflow/Dataproc) → publicados via Analytics Hub
  #    Seção 5.5 e Camada 3/4 do diagrama Hub-and-Spoke Features
  # ----------------------------------------------------------
  "hub-features" = {
    project_id       = "prj-sipml-gateway-prd"
    region           = "southamerica-east1"
    sigla            = "sipml"
    lake_description = "Governança corporativa da camada de dados — RAW, Curated e orquestração Analytics Hub"

    labels = {
      dominio     = "mlops-hub-features"
      cost_center = "ia-caixa"
      owner       = "sudea"
    }

    iam_groups = {
      admin  = "G_GCP_SIPML_ADMIN@corp.caixa.gov.br"
      editor = "G_GCP_SIPML_ENGENHARIA@corp.caixa.gov.br" # único lake com editor — engenharia trata RAW → Curated
      viewer = "G_GCP_SIPML_MODELADORES@corp.caixa.gov.br"
    }

    zones = {
      # Zona RAW: landing zone — dado bruto saindo do SILDC/Dataflow/Pub/Sub
      "raw" = {
        zone_type          = "RAW"
        discovery_enabled  = true
        discovery_schedule = "0 3 * * *"
      }

      # Zona CURATED: dado tratado, pronto para publicação no Analytics Hub
      # Corresponde ao ponto de convergência entre plataforma de dados e MLOps (seção 5.5)
      "curated" = {
        zone_type          = "CURATED"
        discovery_enabled  = true
        discovery_schedule = "0 5 * * *"
      }
    }

    assets = {
      # Landing zone RAW — tabelas puras vindas do SILDC/Dataflow
      "bq-raw-corporativo" = {
        zone_key          = "raw"
        resource_type     = "BIGQUERY_DATASET"
        resource_name     = "projects/prj-sipml-gateway-prd/datasets/ds_raw_corporativo"
        asset_description = "Landing zone corporativa — dados brutos do SILDC e ingestão Dataflow/Dataproc (Camada 3 RAW)"
        discovery_enabled = true
      }

      # Camada Curated — Single Source of Truth publicada via Analytics Hub
      "bq-curated-corporativo" = {
        zone_key          = "curated"
        resource_type     = "BIGQUERY_DATASET"
        resource_name     = "projects/prj-sipml-gateway-prd/datasets/ds_curated_corporativo"
        asset_description = "Camada Curated corporativa — dado governado publicado no Analytics Hub (Camada 3 Curated)"
        discovery_enabled = true
      }
    }

    scans = {
      # Quality scan na camada Curated — porta de qualidade antes de publicar no Analytics Hub
      "curated-quality" = {
        scan_type               = "QUALITY"
        bq_table_resource       = "projects/prj-sipml-gateway-prd/datasets/ds_curated_corporativo/tables/features_corporativas"
        scan_schedule           = "0 4 * * *"
        sampling_percent        = 100
        incremental_field       = "dt_carga"
        export_results_dataset  = "projects/prj-sipml-gateway-prd/datasets/ds_dataplex_results/tables/quality_curated"

        quality_rules = [
          {
            name      = "chave_nao_nula"
            column    = "id_entidade_hash"
            dimension = "COMPLETENESS"
            rule_type = "NON_NULL"
            threshold = 1.0
          },
          {
            name      = "chave_unica"
            column    = "id_entidade_hash"
            dimension = "UNIQUENESS"
            rule_type = "UNIQUENESS"
            threshold = 1.0
          },
          {
            name          = "sem_dados_futuros"
            column        = null
            dimension     = "ACCURACY"
            rule_type     = "SQL"
            sql_statement = "SELECT * FROM features_corporativas WHERE dt_referencia > CURRENT_DATE()"
            threshold     = 1.0
          },
        ]
      }

      # Profile scan Curated — entender shape dos dados antes de publicar
      "curated-profile" = {
        scan_type               = "PROFILE"
        bq_table_resource       = "projects/prj-sipml-gateway-prd/datasets/ds_curated_corporativo/tables/features_corporativas"
        scan_schedule           = "0 8 * * 1"
        sampling_percent        = 20
        export_results_dataset  = "projects/prj-sipml-gateway-prd/datasets/ds_dataplex_results/tables/profile_curated"
        exclude_fields          = ["cpf_hash", "cnpj_hash"]
      }
    }
  }
}
