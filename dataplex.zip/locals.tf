# ============================================================
# Locals — flatten necessário para conectar lake → zone → asset/scan
# Cada item flat carrega project_id/region/sigla próprios, pois os
# módulos filhos não recebem mais o dataplex_settings completo.
# ============================================================

locals {
  zones_flat = merge([
    for lake_key, lake in var.dataplex_settings : {
      for zone_key, zone in lake.zones :
      "${lake_key}__${zone_key}" => merge(zone, {
        lake_key   = lake_key
        project_id = lake.project_id
        region     = lake.region
        sigla      = lake.sigla
        labels     = merge(lake.labels, zone.labels)
      })
    }
  ]...)

  assets_flat = merge([
    for lake_key, lake in var.dataplex_settings : {
      for asset_key, asset in lake.assets :
      "${lake_key}__${asset_key}" => merge(asset, {
        lake_key   = lake_key
        zone_key   = "${lake_key}__${asset.zone_key}"
        project_id = lake.project_id
        region     = lake.region
        sigla      = lake.sigla
        labels     = merge(lake.labels, asset.labels)
      })
    }
  ]...)

  scans_flat = merge([
    for lake_key, lake in var.dataplex_settings : {
      for scan_key, scan in lake.scans :
      "${lake_key}__${scan_key}" => merge(scan, {
        project_id = lake.project_id
        region     = lake.region
        sigla      = lake.sigla
        labels     = merge(lake.labels, scan.labels)
      })
    }
  ]...)
}
