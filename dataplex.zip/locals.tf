# ============================================================
# Dataplex - Locals (flatten das estruturas aninhadas)
# ============================================================

locals {
  # Zones: produz um mapa flat lake_key__zone_key → objeto
  zones_flat = merge([
    for lake_key, lake in var.dataplex_settings : {
      for zone_key, zone in lake.zones :
      "${lake_key}__${zone_key}" => {
        lake_key           = lake_key
        zone_key           = zone_key
        zone_type          = zone.zone_type
        zone_type_slug     = lower(zone.zone_type) # "raw" ou "curated"
        project_id         = lake.project_id
        region             = lake.region
        sigla              = lake.sigla
        location_type      = zone.location_type
        discovery_enabled  = zone.discovery_enabled
        discovery_schedule = zone.discovery_schedule
        csv_delimiter      = zone.csv_delimiter
        labels             = merge(lake.labels, zone.labels)
      }
    }
  ]...)

  # Assets: produz um mapa flat lake_key__asset_key → objeto
  assets_flat = merge([
    for lake_key, lake in var.dataplex_settings : {
      for asset_key, asset in lake.assets :
      "${lake_key}__${asset_key}" => {
        lake_key           = lake_key
        zone_key           = "${lake_key}__${asset.zone_key}"
        project_id         = lake.project_id
        region             = lake.region
        sigla              = lake.sigla
        resource_type      = asset.resource_type
        resource_name      = asset.resource_name
        asset_description  = asset.asset_description
        discovery_enabled  = asset.discovery_enabled
        discovery_schedule = asset.discovery_schedule
        labels             = merge(lake.labels, asset.labels)
      }
    }
  ]...)

  # Scans: produz um mapa flat lake_key__scan_key → objeto
  scans_flat = merge([
    for lake_key, lake in var.dataplex_settings : {
      for scan_key, scan in lake.scans :
      "${lake_key}__${scan_key}" => merge(scan, {
        project_id = lake.project_id
        region     = lake.region
        sigla      = lake.sigla
        labels     = merge(lake.labels, scan.labels)
      })
    }
  ]...)
}
