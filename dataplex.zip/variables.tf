variable "lake_settings" {
  description = "Mapa de lakes a serem criados. Chave = lake_key."
  type = map(object({
    project_id        = string
    region            = string
    sigla             = string
    lake_description  = optional(string, "Lake gerenciado via Terraform")
    metastore_service = optional(string, null)
    labels            = optional(map(string), {})
  }))
}
