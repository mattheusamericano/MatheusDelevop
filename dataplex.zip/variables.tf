# ============================================================
# Dataplex - Variables
# ============================================================

variable "dataplex_settings" {
  description = "Mapa de configurações dos Lakes Dataplex. Cada chave representa um domínio de dados (ex: 'modelagem', 'inferencia', 'hub-features')."
  type = map(object({
    # ----------------------------------------------------------
    # Identificação
    # ----------------------------------------------------------
    project_id = string
    region     = string
    sigla      = string

    lake_description = optional(string, "Lake gerenciado via Terraform")

    # Metastore Dataproc (opcional — para catálogo Hive compartilhado)
    metastore_service = optional(string, null) # ex: "projects/P/locations/R/services/S"

    # ----------------------------------------------------------
    # IAM — grupos fixos por lake
    # admin é obrigatório; editor e viewer são opcionais
    # ----------------------------------------------------------
    iam_groups = object({
      admin  = string               # ex: "G_GCP_SIPML_ADMIN@corp.caixa.gov.br"
      editor = optional(string, null) # omitir ou null = binding não provisionado
      viewer = optional(string, null) # omitir ou null = binding não provisionado
    })

    # ----------------------------------------------------------
    # Zones do lake (RAW e/ou CURATED)
    # ----------------------------------------------------------
    zones = optional(map(object({
      zone_type           = string # "RAW" ou "CURATED"
      location_type       = optional(string, "SINGLE_REGION")
      discovery_enabled   = optional(bool, true)
      discovery_schedule  = optional(string, "0 6 * * *") # cron — null = desabilitado
      csv_delimiter       = optional(string, null)
      labels              = optional(map(string), {})
    })), {})

    # ----------------------------------------------------------
    # Assets dentro das zones
    # ----------------------------------------------------------
    assets = optional(map(object({
      zone_key            = string # chave da zone acima à qual este asset pertence
      resource_type        = string # "BIGQUERY_DATASET" ou "STORAGE_BUCKET"
      resource_name         = string # ex: "projects/P/datasets/D" ou "projects/P/buckets/B"
      asset_description     = optional(string, "Asset gerenciado via Terraform")
      discovery_enabled     = optional(bool, true)
      discovery_schedule    = optional(string, null) # herda da zone se null
      labels                = optional(map(string), {})
    })), {})

    # ----------------------------------------------------------
    # Scans de qualidade e perfil
    # ----------------------------------------------------------
    scans = optional(map(object({
      scan_type         = string # "PROFILE" ou "QUALITY"
      bq_table_resource = string # "projects/P/datasets/D/tables/T"
      scan_schedule     = optional(string, null) # cron ou null (on-demand)
      incremental_field = optional(string, null) # coluna timestamp para scans incrementais
      sampling_percent  = optional(number, 100)  # 0–100
      row_filter        = optional(string, null) # SQL WHERE clause

      # Exportar resultados para outra tabela BQ
      export_results_dataset = optional(string, null) # "projects/P/datasets/D/tables/T"

      # Somente para PROFILE — filtragem de colunas
      include_fields = optional(list(string), [])
      exclude_fields = optional(list(string), [])

      # Somente para QUALITY — lista de regras
      quality_rules = optional(list(object({
        name        = string
        description = optional(string, "")
        column      = optional(string, null) # null = regra de tabela inteira
        dimension   = string # COMPLETENESS, ACCURACY, CONSISTENCY, VALIDITY, UNIQUENESS, INTEGRITY
        threshold   = optional(number, 1.0)  # 0.0–1.0 (100% de sucesso por padrão)
        ignore_null = optional(bool, false)
        rule_type   = string # NON_NULL, UNIQUENESS, RANGE, REGEX, SET, SQL

        # Para RANGE
        range = optional(object({
          min        = optional(string, null)
          max        = optional(string, null)
          strict_min = optional(bool, false)
          strict_max = optional(bool, false)
        }), null)

        # Para REGEX
        regex = optional(string, null)

        # Para SET
        allowed_values = optional(list(string), [])

        # Para SQL (sql_assertion — valida que a query retorna 0 linhas com violação)
        sql_statement = optional(string, null)
      })), [])

      labels = optional(map(string), {})
    })), {})

    # ----------------------------------------------------------
    # Labels globais do lake
    # ----------------------------------------------------------
    labels = optional(map(string), {})
  }))
}
