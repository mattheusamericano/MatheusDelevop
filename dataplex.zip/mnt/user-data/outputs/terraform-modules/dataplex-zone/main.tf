# ============================================================
# Dataplex Zone (RAW ou CURATED)
# ============================================================

resource "google_dataplex_zone" "zone" {
  for_each = var.zone_settings

  project  = each.value.project_id
  location = each.value.region
  lake     = var.lake_names[each.value.lake_key]

  name         = "zone-${lower(each.value.zone_type)}-${each.value.lake_key}-${each.value.sigla}-${terraform.workspace}"
  display_name = "Zone ${upper(each.value.zone_type)} - ${upper(each.value.lake_key)}"
  type         = each.value.zone_type

  resource_spec {
    location_type = each.value.location_type
  }

  discovery_spec {
    enabled  = each.value.discovery_enabled
    schedule = each.value.discovery_schedule

    dynamic "csv_options" {
      for_each = each.value.csv_delimiter != null ? [each.value.csv_delimiter] : []
      content {
        delimiter = csv_options.value
      }
    }
  }

  labels = merge(each.value.labels, {
    environment = terraform.workspace
    managed_by  = "terraform"
    zone_type   = lower(each.value.zone_type)
  })
}
