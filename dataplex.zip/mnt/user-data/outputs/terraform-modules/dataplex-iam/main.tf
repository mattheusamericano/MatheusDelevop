# ============================================================
# Dataplex IAM (no nível do Lake)
# ============================================================
# Roles fixas: admin, editor, viewer
# admin é obrigatório; editor e viewer são opcionais
# ============================================================

resource "google_dataplex_lake_iam_member" "admin" {
  for_each = var.iam_settings

  project  = each.value.project_id
  location = each.value.region
  lake     = var.lake_names[each.key]
  role     = "roles/dataplex.admin"
  member   = "group:${each.value.iam_groups.admin}"
}

resource "google_dataplex_lake_iam_member" "editor" {
  for_each = {
    for k, v in var.iam_settings : k => v
    if v.iam_groups.editor != null
  }

  project  = each.value.project_id
  location = each.value.region
  lake     = var.lake_names[each.key]
  role     = "roles/dataplex.editor"
  member   = "group:${each.value.iam_groups.editor}"
}

resource "google_dataplex_lake_iam_member" "viewer" {
  for_each = {
    for k, v in var.iam_settings : k => v
    if v.iam_groups.viewer != null
  }

  project  = each.value.project_id
  location = each.value.region
  lake     = var.lake_names[each.key]
  role     = "roles/dataplex.viewer"
  member   = "group:${each.value.iam_groups.viewer}"
}
