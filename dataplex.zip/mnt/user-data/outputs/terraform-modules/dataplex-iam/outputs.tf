output "admin_binding_ids" {
  description = "IDs dos bindings de admin criados, indexados por lake_key"
  value = { for k, v in google_dataplex_lake_iam_member.admin : k => v.id }
}
