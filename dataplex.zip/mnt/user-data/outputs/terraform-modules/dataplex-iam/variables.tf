variable "iam_settings" {
  description = "Mapa de IAM por lake. Chave = lake_key."
  type = map(object({
    project_id = string
    region     = string

    iam_groups = object({
      admin  = string
      editor = optional(string, null)
      viewer = optional(string, null)
    })
  }))
}

variable "lake_names" {
  description = "Mapa lake_key → nome do lake — output do módulo dataplex-lake"
  type        = map(string)
}
