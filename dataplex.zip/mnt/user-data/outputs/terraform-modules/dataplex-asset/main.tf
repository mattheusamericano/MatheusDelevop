# ============================================================
# Dataplex Asset (BigQuery dataset ou GCS bucket)
# ============================================================

resource "google_dataplex_asset" "asset" {
  for_each = var.asset_settings

  project       = each.value.project_id
  location      = each.value.region
  lake          = var.lake_names[each.value.lake_key]
  dataplex_zone = var.zone_names[each.value.zone_key]

  name         = "asset-${each.key}-${each.value.sigla}-${terraform.workspace}"
  display_name = "Asset ${upper(replace(each.key, "-", " "))}"
  description  = each.value.asset_description

  resource_spec {
    name = each.value.resource_name
    type = each.value.resource_type
  }

  discovery_spec {
    enabled  = each.value.discovery_enabled
    schedule = each.value.discovery_schedule
  }

  labels = merge(each.value.labels, {
    environment = terraform.workspace
    managed_by  = "terraform"
    asset_type  = lower(each.value.resource_type)
  })
}
