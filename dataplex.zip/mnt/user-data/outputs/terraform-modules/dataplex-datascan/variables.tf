variable "datascan_settings" {
  description = "Mapa de scans a serem criados. Chave = lake_key__scan_key."
  type = map(object({
    project_id              = string
    region                  = string
    sigla                   = string
    scan_type               = string # PROFILE ou QUALITY
    bq_table_resource       = string
    scan_schedule           = optional(string, null)
    incremental_field       = optional(string, null)
    sampling_percent        = optional(number, 100)
    row_filter              = optional(string, null)
    export_results_dataset  = optional(string, null)

    # Específico de PROFILE
    include_fields = optional(list(string), [])
    exclude_fields = optional(list(string), [])

    # Específico de QUALITY
    quality_rules = optional(list(object({
      name        = string
      description = optional(string, "")
      column      = optional(string, null)
      dimension   = string
      threshold   = optional(number, 1.0)
      ignore_null = optional(bool, false)
      rule_type   = string

      range = optional(object({
        min        = optional(string, null)
        max        = optional(string, null)
        strict_min = optional(bool, false)
        strict_max = optional(bool, false)
      }), null)

      regex          = optional(string, null)
      allowed_values = optional(list(string), [])
      sql_statement  = optional(string, null)
    })), [])

    labels = optional(map(string), {})
  }))
}
