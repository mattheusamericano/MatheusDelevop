output "profile_scan_ids" {
  description = "IDs dos Profile Scans criados"
  value = { for k, v in google_dataplex_datascan.profile : k => v.id }
}

output "quality_scan_ids" {
  description = "IDs dos Quality Scans criados"
  value = { for k, v in google_dataplex_datascan.quality : k => v.id }
}
