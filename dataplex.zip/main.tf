# ============================================================
# Dataplex - Lakes
# ============================================================

resource "google_dataplex_lake" "lake" {
  for_each = var.dataplex_settings

  project  = each.value.project_id
  location = each.value.region
  name     = "lake-${each.key}-${each.value.sigla}-${terraform.workspace}"

  display_name = "Lake ${upper(each.key)} ${upper(each.value.sigla)} ${upper(terraform.workspace)}"
  description  = each.value.lake_description

  labels = merge(each.value.labels, {
    environment = terraform.workspace
    managed_by  = "terraform"
    sigla       = each.value.sigla
  })

  dynamic "metastore" {
    for_each = each.value.metastore_service != null ? [each.value.metastore_service] : []
    content {
      service = metastore.value
    }
  }
}

# ============================================================
# Dataplex - Zones (RAW e CURATED por lake)
# ============================================================

resource "google_dataplex_zone" "zone" {
  for_each = local.zones_flat

  project  = each.value.project_id
  location = each.value.region
  lake     = google_dataplex_lake.lake[each.value.lake_key].name

  name         = "zone-${each.value.zone_type_slug}-${each.value.lake_key}-${each.value.sigla}-${terraform.workspace}"
  display_name = "Zone ${upper(each.value.zone_type)} - ${upper(each.value.lake_key)}"
  type         = each.value.zone_type # RAW ou CURATED

  resource_spec {
    location_type = each.value.location_type # SINGLE_REGION ou MULTI_REGION
  }

  discovery_spec {
    enabled  = each.value.discovery_enabled
    schedule = each.value.discovery_schedule

    dynamic "csv_options" {
      for_each = each.value.csv_delimiter != null ? [each.value.csv_delimiter] : []
      content {
        delimiter = csv_options.value
      }
    }
  }

  labels = merge(each.value.labels, {
    environment = terraform.workspace
    managed_by  = "terraform"
    zone_type   = lower(each.value.zone_type)
  })
}

# ============================================================
# Dataplex - Assets (BigQuery datasets e GCS buckets)
# ============================================================

resource "google_dataplex_asset" "asset" {
  for_each = local.assets_flat

  project       = each.value.project_id
  location      = each.value.region
  lake          = google_dataplex_lake.lake[each.value.lake_key].name
  dataplex_zone = google_dataplex_zone.zone[each.value.zone_key].name

  name         = "asset-${each.key}-${each.value.sigla}-${terraform.workspace}"
  display_name = "Asset ${upper(replace(each.key, "-", " "))}"
  description  = each.value.asset_description

  resource_spec {
    name = each.value.resource_name # formato: projects/P/datasets/D ou projects/P/buckets/B
    type = each.value.resource_type # BIGQUERY_DATASET ou STORAGE_BUCKET
  }

  discovery_spec {
    enabled  = each.value.discovery_enabled
    schedule = each.value.discovery_schedule
  }

  labels = merge(each.value.labels, {
    environment = terraform.workspace
    managed_by  = "terraform"
    asset_type  = lower(each.value.resource_type)
  })
}

# ============================================================
# Dataplex - Data Profile Scans
# ============================================================

resource "google_dataplex_datascan" "profile" {
  for_each = { for k, v in local.scans_flat : k => v if v.scan_type == "PROFILE" }

  project       = each.value.project_id
  location      = each.value.region
  data_scan_id  = "scan-profile-${each.key}-${each.value.sigla}-${terraform.workspace}"
  display_name  = "Profile Scan - ${upper(each.key)}"

  data {
    resource = each.value.bq_table_resource # projects/P/datasets/D/tables/T
  }

  execution_spec {
    trigger {
      dynamic "schedule" {
        for_each = each.value.scan_schedule != null ? [each.value.scan_schedule] : []
        content {
          cron = schedule.value
        }
      }
      dynamic "on_demand" {
        for_each = each.value.scan_schedule == null ? [1] : []
        content {}
      }
    }
    field = each.value.incremental_field # null = full scan
  }

  data_profile_spec {
    sampling_percent = each.value.sampling_percent
    row_filter        = each.value.row_filter

    dynamic "post_scan_actions" {
      for_each = each.value.export_results_dataset != null ? [each.value.export_results_dataset] : []
      content {
        bigquery_export {
          results_table = post_scan_actions.value
        }
      }
    }

    dynamic "include_fields" {
      for_each = length(each.value.include_fields) > 0 ? [each.value.include_fields] : []
      content {
        field_names = include_fields.value
      }
    }

    dynamic "exclude_fields" {
      for_each = length(each.value.exclude_fields) > 0 ? [each.value.exclude_fields] : []
      content {
        field_names = exclude_fields.value
      }
    }
  }

  labels = merge(each.value.labels, {
    environment = terraform.workspace
    managed_by  = "terraform"
    scan_type   = "profile"
  })
}

# ============================================================
# Dataplex - Data Quality Scans
# ============================================================

resource "google_dataplex_datascan" "quality" {
  for_each = { for k, v in local.scans_flat : k => v if v.scan_type == "QUALITY" }

  project      = each.value.project_id
  location     = each.value.region
  data_scan_id = "scan-quality-${each.key}-${each.value.sigla}-${terraform.workspace}"
  display_name = "Quality Scan - ${upper(each.key)}"

  data {
    resource = each.value.bq_table_resource
  }

  execution_spec {
    trigger {
      dynamic "schedule" {
        for_each = each.value.scan_schedule != null ? [each.value.scan_schedule] : []
        content {
          cron = schedule.value
        }
      }
      dynamic "on_demand" {
        for_each = each.value.scan_schedule == null ? [1] : []
        content {}
      }
    }
    field = each.value.incremental_field
  }

  data_quality_spec {
    sampling_percent = each.value.sampling_percent
    row_filter        = each.value.row_filter

    dynamic "rules" {
      for_each = each.value.quality_rules
      content {
        column      = rules.value.column
        dimension   = rules.value.dimension # COMPLETENESS, ACCURACY, CONSISTENCY, VALIDITY, UNIQUENESS, INTEGRITY
        name        = rules.value.name
        description = rules.value.description
        threshold   = rules.value.threshold # porcentagem mínima de sucesso (0.0–1.0)
        ignore_null = rules.value.ignore_null

        dynamic "non_null_expectation" {
          for_each = rules.value.rule_type == "NON_NULL" ? [1] : []
          content {}
        }

        dynamic "uniqueness_expectation" {
          for_each = rules.value.rule_type == "UNIQUENESS" ? [1] : []
          content {}
        }

        dynamic "range_expectation" {
          for_each = rules.value.rule_type == "RANGE" && rules.value.range != null ? [rules.value.range] : []
          content {
            min_value          = range_expectation.value.min
            max_value          = range_expectation.value.max
            strict_min_enabled = range_expectation.value.strict_min
            strict_max_enabled = range_expectation.value.strict_max
          }
        }

        dynamic "regex_expectation" {
          for_each = rules.value.rule_type == "REGEX" && rules.value.regex != null ? [rules.value.regex] : []
          content {
            regex = regex_expectation.value
          }
        }

        dynamic "set_expectation" {
          for_each = rules.value.rule_type == "SET" && length(rules.value.allowed_values) > 0 ? [rules.value.allowed_values] : []
          content {
            values = set_expectation.value
          }
        }

        dynamic "sql_assertion" {
          for_each = rules.value.rule_type == "SQL" && rules.value.sql_statement != null ? [rules.value.sql_statement] : []
          content {
            sql_statement = sql_assertion.value
          }
        }
      }
    }

    dynamic "post_scan_actions" {
      for_each = each.value.export_results_dataset != null ? [each.value.export_results_dataset] : []
      content {
        bigquery_export {
          results_table = post_scan_actions.value
        }
      }
    }
  }

  labels = merge(each.value.labels, {
    environment = terraform.workspace
    managed_by  = "terraform"
    scan_type   = "quality"
  })
}
