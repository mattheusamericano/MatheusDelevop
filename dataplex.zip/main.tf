# ============================================================
# Root module — orquestra os 5 módulos Dataplex
# ============================================================
# Cada módulo é chamado 1x só (sem for_each na chamada) e itera
# internamente sobre o map recebido via _settings.
#
# Troque o "source" pelo endereço git do seu repo de módulos, ex:
#   source = "git::https://github.com/sua-org/terraform-modules.git//dataplex-lake?ref=v1.0.0"
# ============================================================

# ----------------------------------------------------------
# Lakes
# ----------------------------------------------------------
module "dataplex_lake" {
  source = "../terraform-modules/dataplex-lake"

  lake_settings = {
    for lake_key, lake in var.dataplex_settings :
    lake_key => {
      project_id        = lake.project_id
      region            = lake.region
      sigla             = lake.sigla
      lake_description  = lake.lake_description
      metastore_service = lake.metastore_service
      labels            = lake.labels
    }
  }
}

# ----------------------------------------------------------
# Zones
# ----------------------------------------------------------
module "dataplex_zone" {
  source = "../terraform-modules/dataplex-zone"

  zone_settings = local.zones_flat
  lake_names    = module.dataplex_lake.names
}

# ----------------------------------------------------------
# Assets
# ----------------------------------------------------------
module "dataplex_asset" {
  source = "../terraform-modules/dataplex-asset"

  asset_settings = local.assets_flat
  lake_names     = module.dataplex_lake.names
  zone_names     = module.dataplex_zone.names
}

# ----------------------------------------------------------
# Datascans
# ----------------------------------------------------------
module "dataplex_datascan" {
  source = "../terraform-modules/dataplex-datascan"

  datascan_settings = local.scans_flat
}

# ----------------------------------------------------------
# IAM (por lake)
# ----------------------------------------------------------
module "dataplex_iam" {
  source = "../terraform-modules/dataplex-iam"

  iam_settings = {
    for lake_key, lake in var.dataplex_settings :
    lake_key => {
      project_id = lake.project_id
      region     = lake.region
      iam_groups = lake.iam_groups
    }
  }
  lake_names = module.dataplex_lake.names
}
