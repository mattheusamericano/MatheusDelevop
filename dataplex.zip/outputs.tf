# ============================================================
# Dataplex - Outputs
# ============================================================

output "lake_ids" {
  description = "IDs dos Lakes criados, indexados pela chave do mapa"
  value = {
    for k, v in google_dataplex_lake.lake : k => v.id
  }
}

output "lake_names" {
  description = "Nomes dos Lakes criados"
  value = {
    for k, v in google_dataplex_lake.lake : k => v.name
  }
}

output "zone_ids" {
  description = "IDs das Zones criadas, indexadas por lake_key__zone_key"
  value = {
    for k, v in google_dataplex_zone.zone : k => v.id
  }
}

output "asset_ids" {
  description = "IDs dos Assets criados, indexados por lake_key__asset_key"
  value = {
    for k, v in google_dataplex_asset.asset : k => v.id
  }
}

output "profile_scan_ids" {
  description = "IDs dos Profile Scans criados"
  value = {
    for k, v in google_dataplex_datascan.profile : k => v.data_scan_id
  }
}

output "quality_scan_ids" {
  description = "IDs dos Quality Scans criados"
  value = {
    for k, v in google_dataplex_datascan.quality : k => v.data_scan_id
  }
}
