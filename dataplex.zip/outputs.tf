output "lake_ids" {
  value = module.dataplex_lake.ids
}

output "lake_names" {
  value = module.dataplex_lake.names
}

output "zone_ids" {
  value = module.dataplex_zone.ids
}

output "asset_ids" {
  value = module.dataplex_asset.ids
}

output "profile_scan_ids" {
  value = module.dataplex_datascan.profile_scan_ids
}

output "quality_scan_ids" {
  value = module.dataplex_datascan.quality_scan_ids
}
