# ============================================================
# Analytics Hub - Variables
# ============================================================

variable "analytics_hub_settings" {
  description = "Mapa de configurações dos Data Exchanges do Analytics Hub. Cada chave representa um exchange (ex: 'features-corporativas', 'logs-operacionais')."
  type = map(object({
    # ----------------------------------------------------------
    # Identificação
    # ----------------------------------------------------------
    project_id   = string
    region       = string
    sigla        = string
    display_name = string
    description  = optional(string, "Exchange gerenciado via Terraform")

    # ----------------------------------------------------------
    # Visibilidade
    # ----------------------------------------------------------
    # true  = Exchange Privado (DCR) — padrão Caixa, acesso controlado por IAM
    # false = Exchange Público/Aberto — qualquer usuário da org pode descobrir e assinar
    is_private = optional(bool, true)

    # Quando is_private = true: impede que um subscriber compartilhe o listing
    # com outros projetos após assinar. Recomendado manter true em ambientes bancários.
    restrict_single_resource = optional(bool, true)

    # ----------------------------------------------------------
    # Listings dentro do exchange
    # ----------------------------------------------------------
    listings = optional(map(object({
      display_name  = string
      description   = optional(string, "Listing gerenciado via Terraform")
      documentation = optional(string, null) # URL ou markdown com docs do dataset

      # Dataset BQ que será exposto no listing
      # Formato: "projects/PROJECT_ID/datasets/DATASET_ID"
      bq_dataset_resource = string

      # Tabelas específicas a expor (lista vazia = expõe o dataset inteiro)
      # Formato: ["projects/P/datasets/D/tables/T1", "projects/P/datasets/D/tables/T2"]
      selected_tables = optional(list(string), [])

      # Ícone do listing (base64 PNG, máx 128x128px) — opcional
      icon_base64 = optional(string, null)

      # Data steward / publisher do listing
      publisher_name    = optional(string, null) # ex: "SUDEA — Superintendência de Engenharia de Dados"
      publisher_contact = optional(string, null) # ex: "sudea@caixa.gov.br"

      # Categorias do catálogo Analytics Hub
      # Valores válidos: CATEGORY_OTHERS, CATEGORY_ADVERTISING_AND_MARKETING,
      # CATEGORY_COMMERCE, CATEGORY_CLIMATE_AND_ENVIRONMENT, CATEGORY_DEMOGRAPHICS,
      # CATEGORY_ECONOMICS, CATEGORY_EDUCATION, CATEGORY_ENERGY,
      # CATEGORY_FINANCIAL_MARKETS, CATEGORY_HEALTHCARE, CATEGORY_PUBLIC_SECTOR,
      # CATEGORY_RETAIL, CATEGORY_SCIENCE_AND_RESEARCH, CATEGORY_SPORTS,
      # CATEGORY_TRANSPORTATION_AND_LOGISTICS, CATEGORY_TRAVEL_AND_TOURISM
      categories = optional(list(string), ["CATEGORY_OTHERS"])

      labels = optional(map(string), {})
    })), {})

    # ----------------------------------------------------------
    # IAM no Exchange (quem pode publicar e quem pode assinar)
    # ----------------------------------------------------------
    # Estrutura: { "roles/analyticshub.publisher" = ["group:...", "serviceAccount:..."] }
    # Roles relevantes:
    #   roles/analyticshub.admin           — administração total do exchange
    #   roles/analyticshub.dataExchangeAdmin — admin do exchange (alias)
    #   roles/analyticshub.publisher       — pode criar/gerenciar listings
    #   roles/analyticshub.subscriber      — pode assinar listings
    #   roles/analyticshub.viewer          — pode visualizar/descobrir listings
    iam_bindings = optional(map(list(string)), {})

    # ----------------------------------------------------------
    # Labels globais do exchange
    # ----------------------------------------------------------
    labels = optional(map(string), {})
  }))
}
