# ============================================================
# Analytics Hub - SIPML
# ============================================================
# Contexto: prj-sipml-gateway-prd (Hub Central de Orquestração)
#
# O Analytics Hub atua na Camada 4 (Orquestração e Governança) do diagrama
# Hub-and-Spoke Features, junto ao Dataplex.
#
# Fluxo:
#   Dados Curated (BQ) → Analytics Hub (Exchange/Listing) → Spokes (linked datasets)
#
# Exchanges criados:
#   1. features-corporativas → dados curados para consumo pelos spokes de modelagem/inferência
#   2. logs-observabilidade  → logs analíticos para squads de observabilidade e governança
#
# Nota: todos os exchanges são PRIVADOS (is_private = true) conforme padrão Caixa.
# Para liberar um exchange para discovery interno amplo, setar is_private = false.
# ============================================================

analytics_hub_settings = {

  # ----------------------------------------------------------
  # Exchange: Features Corporativas
  # Publica a camada Curated do Hub para os Spokes de Modelagem e Inferência
  # Seção 5.5 / Camada 4 do documento: Analytics Hub como Share Data
  # ----------------------------------------------------------
  "features-corporativas" = {
    project_id   = "prj-sipml-gateway-prd"
    region       = "southamerica-east1"
    sigla        = "sipml"
    display_name = "SIPML — Features Corporativas"
    description  = "Exchange privado de features corporativas para consumo pelos spokes de modelagem e inferência. Dado curado e governado via Dataplex."
    is_private   = true
    restrict_single_resource = true

    labels = {
      dominio     = "mlops-hub-features"
      cost_center = "ia-caixa"
      owner       = "sudea"
      tipo        = "features"
    }

    # IAM no Exchange
    iam_bindings = {
      # SUDEA administra o exchange
      "roles/analyticshub.admin" = [
        "group:G_GCP_SIPML_ADMIN@corp.caixa.gov.br",
      ]
      # Times modeladores podem publicar seus próprios listings
      "roles/analyticshub.publisher" = [
        "group:G_GCP_SIPML_ENGENHARIA@corp.caixa.gov.br",
      ]
      # Spokes de modelagem e inferência podem assinar
      "roles/analyticshub.subscriber" = [
        "group:G_GCP_SIPML_MODELADORES@corp.caixa.gov.br",
        "group:G_GCP_SIPML_OPERACAO@corp.caixa.gov.br",
      ]
      # Cientistas de dados podem descobrir e visualizar listings
      "roles/analyticshub.viewer" = [
        "group:G_GCP_SIPML_MODELADORES@corp.caixa.gov.br",
      ]
    }

    listings = {
      # ----------------------------------------------------------
      # Listing: Features Consolidadas (camada Curated)
      # Consumidas pelo spoke-modelagem (treino) e spoke-inferencia (lookup)
      # ----------------------------------------------------------
      "features-consolidadas" = {
        display_name        = "Features Consolidadas — Curated"
        description         = "Features corporativas tratadas e validadas pelo Dataplex. Prontas para treinamento de modelos e lookup de inferência online."
        documentation       = "https://confluence.caixa.gov.br/sipml/features-consolidadas"
        bq_dataset_resource = "projects/prj-sipml-gateway-prd/datasets/ds_curated_corporativo"
        selected_tables     = [] # expõe o dataset inteiro — tabelas controladas por IAM BQ
        publisher_name      = "SUDEA — Superintendência de Engenharia de Dados e Analytics"
        publisher_contact   = "sudea@caixa.gov.br"
        categories          = ["CATEGORY_FINANCIAL_MARKETS", "CATEGORY_SCIENCE_AND_RESEARCH"]

        labels = {
          camada  = "curated"
          uso     = "treino-e-inferencia"
        }
      }

      # ----------------------------------------------------------
      # Listing: Features RAW (camada de Landing)
      # Consumidas apenas pelo spoke-modelagem para P&D e feature engineering
      # ----------------------------------------------------------
      "features-raw" = {
        display_name        = "Features RAW — Landing Zone"
        description         = "Dado bruto de landing — uso restrito a P&D e feature engineering. Não utilizar em produção sem curadoria."
        bq_dataset_resource = "projects/prj-sipml-gateway-prd/datasets/ds_raw_corporativo"
        selected_tables     = [] # cientistas de dados acessam todas as tabelas da landing
        publisher_name      = "SUDEA — Superintendência de Engenharia de Dados e Analytics"
        publisher_contact   = "sudea@caixa.gov.br"
        categories          = ["CATEGORY_SCIENCE_AND_RESEARCH"]

        labels = {
          camada  = "raw"
          uso     = "pesquisa-e-desenvolvimento"
        }
      }
    }
  }

  # ----------------------------------------------------------
  # Exchange: Logs de Observabilidade
  # Publica logs analíticos de predições e Model Monitoring
  # para squads de observabilidade, risco e governança
  # ADR-009: Stack de observabilidade (BigQuery + Looker Studio)
  # ----------------------------------------------------------
  "logs-observabilidade" = {
    project_id   = "prj-sipml-gateway-prd"
    region       = "southamerica-east1"
    sigla        = "sipml"
    display_name = "SIPML — Logs de Observabilidade"
    description  = "Exchange privado de logs analíticos de predições, drift e métricas operacionais dos modelos. Base para dashboards Looker Studio e análises de governança."
    is_private   = true
    restrict_single_resource = true

    labels = {
      dominio     = "mlops-observabilidade"
      cost_center = "ia-caixa"
      owner       = "sudea"
      tipo        = "logs"
    }

    iam_bindings = {
      "roles/analyticshub.admin" = [
        "group:G_GCP_SIPML_ADMIN@corp.caixa.gov.br",
      ]
      "roles/analyticshub.publisher" = [
        "group:G_GCP_SIPML_ENGENHARIA@corp.caixa.gov.br",
      ]
      # Times de observabilidade e risco podem assinar
      "roles/analyticshub.subscriber" = [
        "group:G_GCP_SIPML_OBSERVABILIDADE@corp.caixa.gov.br",
        "group:G_GCP_RISCFAB_DTSC@corp.caixa.gov.br",
      ]
      "roles/analyticshub.viewer" = [
        "group:G_GCP_SIPML_OBSERVABILIDADE@corp.caixa.gov.br",
      ]
    }

    listings = {
      # ----------------------------------------------------------
      # Listing: Logs de Predições Operacionais
      # Base para dashboards e análise de drift (ADR-009)
      # ----------------------------------------------------------
      "logs-predicoes" = {
        display_name        = "Logs de Predições — Operacional"
        description         = "Logs analíticos de todas as predições executadas pelos spokes de inferência. Inclui score, features utilizadas e latência. Base para Model Monitoring e detecção de drift."
        documentation       = "https://confluence.caixa.gov.br/sipml/logs-predicoes"
        bq_dataset_resource = "projects/prj-sipml-gateway-prd/datasets/ds_logs_analíticos"
        # Expor apenas a tabela de predições — não expor tabelas de auditoria interna
        selected_tables = [
          "projects/prj-sipml-gateway-prd/datasets/ds_logs_analíticos/tables/predicoes_consolidadas",
          "projects/prj-sipml-gateway-prd/datasets/ds_logs_analíticos/tables/metricas_drift",
        ]
        publisher_name    = "SUDEA — Superintendência de Engenharia de Dados e Analytics"
        publisher_contact = "sudea@caixa.gov.br"
        categories        = ["CATEGORY_FINANCIAL_MARKETS"]

        labels = {
          tipo = "logs-operacionais"
          pii  = "false" # logs de predição são anonimizados antes da publicação
        }
      }
    }
  }
}
