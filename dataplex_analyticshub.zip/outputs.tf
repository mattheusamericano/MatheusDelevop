# ============================================================
# Analytics Hub - Outputs
# ============================================================

output "exchange_ids" {
  description = "IDs dos Data Exchanges criados, indexados pela chave do mapa"
  value = {
    for k, v in google_bigquery_analytics_hub_data_exchange.exchange : k => v.id
  }
}

output "exchange_names" {
  description = "data_exchange_id de cada Exchange (usado para referenciar em outros módulos)"
  value = {
    for k, v in google_bigquery_analytics_hub_data_exchange.exchange : k => v.data_exchange_id
  }
}

output "listing_ids" {
  description = "IDs dos Listings criados, indexados por exchange_key__listing_key"
  value = {
    for k, v in google_bigquery_analytics_hub_listing.listing : k => v.id
  }
}

output "listing_names" {
  description = "listing_id de cada Listing (usado para operações de subscribe via gcloud/API)"
  value = {
    for k, v in google_bigquery_analytics_hub_listing.listing : k => v.listing_id
  }
}
