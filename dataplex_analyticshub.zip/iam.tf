# ============================================================
# Analytics Hub - IAM
# ============================================================

# IAM no Exchange — publishers, subscribers e admins
resource "google_bigquery_analytics_hub_data_exchange_iam_member" "exchange_iam" {
  for_each = local.exchange_iam_flat

  project          = each.value.project_id
  location         = each.value.region
  data_exchange_id = google_bigquery_analytics_hub_data_exchange.exchange[each.value.exchange_key].data_exchange_id
  role             = each.value.role
  member           = each.value.member
}

# IAM em Listings específicos — controle fino por listing
resource "google_bigquery_analytics_hub_listing_iam_member" "listing_iam" {
  for_each = local.listing_iam_flat

  project          = each.value.project_id
  location         = each.value.region
  data_exchange_id = google_bigquery_analytics_hub_data_exchange.exchange[each.value.exchange_key].data_exchange_id
  listing_id       = google_bigquery_analytics_hub_listing.listing[each.value.listing_key].listing_id
  role             = each.value.role
  member           = each.value.member
}
