# ============================================================
# Analytics Hub - Data Exchanges e Listings
# ============================================================
# Escopo inicial: Exchange Privado + Listings
# Flag is_private controla visibilidade (padrão: true)
# ============================================================

resource "google_bigquery_analytics_hub_data_exchange" "exchange" {
  for_each = var.analytics_hub_settings

  project          = each.value.project_id
  location         = each.value.region
  data_exchange_id = "exchange_${replace(each.key, "-", "_")}_${each.value.sigla}_${terraform.workspace}"
  display_name     = each.value.display_name
  description      = each.value.description

  # Controle de visibilidade: privado por padrão (padrão Caixa)
  # Setar is_private = false para exchanges públicos/internos abertos
  sharing_environment_config {
    dynamic "default_exchange_config" {
      for_each = !each.value.is_private ? [1] : []
      content {}
    }

    dynamic "dcr_exchange_config" {
      for_each = each.value.is_private ? [1] : []
      content {
        single_selected_resource_sharing_restriction = each.value.restrict_single_resource
      }
    }
  }

  labels = merge(each.value.labels, {
    environment = terraform.workspace
    managed_by  = "terraform"
    sigla       = each.value.sigla
    visibility  = each.value.is_private ? "private" : "public"
  })
}

# ============================================================
# Analytics Hub - Listings
# ============================================================

resource "google_bigquery_analytics_hub_listing" "listing" {
  for_each = local.listings_flat

  project          = each.value.project_id
  location         = each.value.region
  data_exchange_id = google_bigquery_analytics_hub_data_exchange.exchange[each.value.exchange_key].data_exchange_id
  listing_id       = "listing_${replace(each.key, "-", "_")}_${each.value.sigla}_${terraform.workspace}"
  display_name     = each.value.display_name
  description      = each.value.description
  documentation    = each.value.documentation
  icon             = each.value.icon_base64 # opcional — ícone do listing em base64

  # Dataset BigQuery que será compartilhado
  bigquery_dataset {
    dataset = each.value.bq_dataset_resource # "projects/P/datasets/D"

    dynamic "selected_resources" {
      for_each = each.value.selected_tables
      content {
        table = selected_resources.value # "projects/P/datasets/D/tables/T"
      }
    }
  }

  # Contato do publisher (data steward)
  dynamic "publisher" {
    for_each = each.value.publisher_name != null ? [1] : []
    content {
      name            = each.value.publisher_name
      primary_contact = each.value.publisher_contact
    }
  }

  # Categorias do listing no catálogo (ex: CATEGORY_OTHERS, CATEGORY_SCIENCE_AND_RESEARCH)
  categories = each.value.categories

  labels = merge(each.value.labels, {
    environment  = terraform.workspace
    managed_by   = "terraform"
    exchange_key = each.value.exchange_key
  })
}
