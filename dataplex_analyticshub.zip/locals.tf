# ============================================================
# Analytics Hub - Locals
# ============================================================

locals {
  # Listings: produz mapa flat exchange_key__listing_key → objeto
  listings_flat = merge([
    for exchange_key, exchange in var.analytics_hub_settings : {
      for listing_key, listing in exchange.listings :
      "${exchange_key}__${listing_key}" => merge(listing, {
        exchange_key = exchange_key
        project_id   = exchange.project_id
        region       = exchange.region
        sigla        = exchange.sigla
        labels       = merge(exchange.labels, listing.labels)
      })
    }
  ]...)

  # IAM flat: exchange_key__role__member → objeto
  exchange_iam_flat = merge([
    for exchange_key, exchange in var.analytics_hub_settings : merge([
      for role, members in exchange.iam_bindings : {
        for member in members :
        "${exchange_key}__${role}__${member}" => {
          exchange_key = exchange_key
          project_id   = exchange.project_id
          region       = exchange.region
          role         = role
          member       = member
        }
      }
    ]...)
  ]...)

  # Listing IAM flat — quem pode assinar listing específico
  listing_iam_flat = merge([
    for exchange_key, exchange in var.analytics_hub_settings : merge([
      for listing_key, listing in exchange.listings : merge([
        for role, members in try(listing.iam_bindings, {}) : {
          for member in members :
          "${exchange_key}__${listing_key}__${role}__${member}" => {
            exchange_key = exchange_key
            listing_key  = "${exchange_key}__${listing_key}"
            project_id   = exchange.project_id
            region       = exchange.region
            role         = role
            member       = member
          }
        }
      ]...)
    ]...)
  ]...)
}
